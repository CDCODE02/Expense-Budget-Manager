package com.demo.example.dailyincomeexpensemanager;


public class TAG {
    public static String CATEGORY = "category";
    public static String DATA = "data";
    public static String RECURRING = "recurring";
}
