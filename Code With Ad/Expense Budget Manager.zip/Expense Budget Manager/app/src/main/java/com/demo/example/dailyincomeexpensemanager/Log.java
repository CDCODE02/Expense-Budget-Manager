package com.demo.example.dailyincomeexpensemanager;


public class Log {
    private static String TAG = "DIEM";

    
    public static void m953d(String str) {
        android.util.Log.e(TAG, str);
    }
}
