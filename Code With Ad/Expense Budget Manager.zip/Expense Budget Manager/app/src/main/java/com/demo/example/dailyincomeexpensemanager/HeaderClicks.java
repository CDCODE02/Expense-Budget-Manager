package com.demo.example.dailyincomeexpensemanager;

import android.view.View;


public interface HeaderClicks {
    void onAddClick(View view);

    void onGeneralSettingClick(View view);
}
