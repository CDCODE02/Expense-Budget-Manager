

package org.apache.harmony.javax.security.auth.callback;


public interface Callback {
}